<?php

class ControladorRuta{

	static public function ctrRuta(){

		return "http://localhost/reservas-hotel/";

	}

	static public function ctrServidor(){

		return "http://localhost/reservas-hotel/backend/";
	}

}