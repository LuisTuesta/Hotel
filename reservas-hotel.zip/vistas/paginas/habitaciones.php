<?php

include "modulos/banner-interior.php";
include "modulos/info-habitaciones.php";
include "modulos/testimonios.php";
include "modulos/planes.php";
include "modulos/planes-movil.php";
include "modulos/recorrido-pueblo.php";
include "modulos/restaurante.php";