<?php

include "modulos/banner.php";

include "modulos/planes.php";

include "modulos/habitaciones.php";

include "modulos/planes-movil.php";

include "modulos/recorrido-pueblo.php";

include "modulos/restaurante.php";