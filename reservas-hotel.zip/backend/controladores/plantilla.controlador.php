<?php 

class ControladorPlantilla{

	/*=============================================
	=       METODO QUE INCLUYE LA PLANTILLA          =
	=============================================*/
	
	public function ctrPlantilla(){

		include "vistas/plantilla.php";
		
	}
	


}