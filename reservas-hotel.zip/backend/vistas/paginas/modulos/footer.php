<footer class="main-footer">

	<strong>Copyright © <?php echo date("Y"); ?>  <a href="<?php echo $ruta; ?>" target="_blank">HOTEL PARACAS</a>.</strong> Todos los derechos reservados.

</footer>